import argparse
import os
import yaml

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer


def get_args():
    """
    Считывание параметров
    path_in - путь получения датасета
    path_out - путь куда сохраняются преобразованные данные
                разделенные на train/test
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("-path_in", action="store", dest="path_in", required=True)
    parser.add_argument("-path_out", action="store", dest="path_out")
    args = parser.parse_args()
    return args


def prepare_train(train: pd.DataFrame):
    """
    Преобразование данных
    """
    temp = train[["Age"]]
    train.drop(["Age"], inplace=True, axis=1)

    my_imputer = SimpleImputer()
    imputed_temp = pd.DataFrame(my_imputer.fit_transform(temp))
    imputed_temp.columns = temp.columns

    train = pd.concat([train, imputed_temp], axis=1)

    train["Embarked"].fillna(train["Embarked"].mode(), inplace=True)
    dummy1 = pd.get_dummies(train[["Sex", "Embarked"]])
    train.drop(["Cabin", "Embarked"], axis=1, inplace=True)
    train = pd.concat([train, dummy1], axis=1)
    train.drop(["Name", "PassengerId", "Sex", "Ticket"], axis=1, inplace=True)

    y = train["Survived"]
    train.drop(["Survived"], axis=1, inplace=True)
    return train, y


if __name__ == "__main__":
    args = get_args()
    train = pd.read_csv(args.path_in)

    x, y = prepare_train(train)

    x_train, x_test, y_train, y_test = train_test_split(x, y, random_state=42)

    os.makedirs(os.path.join(args.path_out.split("/")[0]), exist_ok=True)
    x_train.to_csv(f"{args.path_out}/x_train.csv", index=False)
    y_train.to_csv(f"{args.path_out}/y_train.csv", index=False)
    x_test.to_csv(f"{args.path_out}/x_test.csv", index=False)
    y_test.to_csv(f"{args.path_out}/y_test.csv", index=False)
