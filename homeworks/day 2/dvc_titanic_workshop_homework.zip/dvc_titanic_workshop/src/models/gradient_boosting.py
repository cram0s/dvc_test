"""
Команда запуска скрипта из терминала,
параметры использованны по умолчанию,
запускается из корневой директории проекта
python src/models/gradient_boosting.py \
-x_train='data/x_train.csv' \
-y_train='data/y_train.csv' \
-path_pkl='models/gradient_boosting.pkl'

Команда запуска из консоли IPython в Jupyther Lab
%run src/models/gradient_boosting.py \
-x_train='data/x_train.csv' \
-y_train='data/y_train.csv' \
-path_pkl='models/gradient_boosting.pkl'
"""
import argparse
import os
import yaml

import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
import pickle


def get_args():
    """
    Считывание параметров
    x_train - путь получения датасета со свойствами
    y_train - путь получения датасета со значениями
    path_pkl - путь сохранения бинарного файла обученной модели
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("-x_train", action="store", dest="x_train", required=True)
    parser.add_argument("-y_train", action="store", dest="y_train", required=True)
    parser.add_argument("-path_pkl", action="store", dest="path_pkl")
    args = parser.parse_args()
    return args


def model(x, y, learnin_rate):
    """
    Создание и обучение модели
    """
    model = GradientBoostingClassifier(learning_rate=learnin_rate)
    model.fit(x, y.values.ravel())
    return model


if __name__ == "__main__":
    args = get_args()
    x_train = pd.read_csv(args.x_train)
    y_train = pd.read_csv(args.y_train)
    learnin_rate = 0.3
    gb = model(x_train, y_train, learnin_rate)

    with open(args.path_pkl, "wb") as fd:
        pickle.dump(gb, fd)
