import argparse
import json

import pandas as pd
import pickle
from sklearn.metrics import f1_score
import pickle

def get_args():
    """
    Считывание параметров
    x_train - путь получения датасета со свойствами
    y_train - путь получения датасета со значениями
    path_pkl - путь сохранения бинарного файла обученной модели
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("-x_test", action="store", dest="x_test", required=True)
    parser.add_argument("-y_test", action="store", dest="y_test", required=True)
    parser.add_argument("-path_pkl", action="store", dest="path_pkl")
    args = parser.parse_args()
    return args


if __name__ == "__main__":
    args = get_args()
    x_test = pd.read_csv(args.x_test)
    y_test = pd.read_csv(args.y_test)

    gb = pickle.load(open(args.path_pkl, 'rb'))

    y_pred = gb.predict(x_test)

    score = f1_score(y_test, y_pred)

    metrics = {"f1_score": score}

    with open("reports/model_metrics.json", 'w') as fd:
        json.dump(metrics, fd)
